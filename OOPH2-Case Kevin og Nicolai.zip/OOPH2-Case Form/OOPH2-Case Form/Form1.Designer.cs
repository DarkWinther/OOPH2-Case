﻿namespace OOPH2_Case_Form
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.OpretKunde_btn = new System.Windows.Forms.Button();
            this.FjernKunde_btn = new System.Windows.Forms.Button();
            this.VisKonto_btn = new System.Windows.Forms.Button();
            this.OpretKonto_btn = new System.Windows.Forms.Button();
            this.FjernKonto_btn = new System.Windows.Forms.Button();
            this.Hæv_btn = new System.Windows.Forms.Button();
            this.Indsæt_btn = new System.Windows.Forms.Button();
            this.UdskrivTrans_btn = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Submit_btn = new System.Windows.Forms.Button();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.Saldo_label = new System.Windows.Forms.Label();
            this.SøgKunde_text = new System.Windows.Forms.TextBox();
            this.SøgKunde_label = new System.Windows.Forms.Label();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.SamletBeløb_label = new System.Windows.Forms.Label();
            this.ValgteKunde_label = new System.Windows.Forms.Label();
            this.SøgKonto_text = new System.Windows.Forms.TextBox();
            this.SøgKonto_label = new System.Windows.Forms.Label();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.label20 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.Kundeoversigt_btn = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            this.SuspendLayout();
            // 
            // OpretKunde_btn
            // 
            this.OpretKunde_btn.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OpretKunde_btn.Location = new System.Drawing.Point(10, 12);
            this.OpretKunde_btn.Name = "OpretKunde_btn";
            this.OpretKunde_btn.Size = new System.Drawing.Size(96, 32);
            this.OpretKunde_btn.TabIndex = 0;
            this.OpretKunde_btn.Text = "Opret kunde";
            this.OpretKunde_btn.UseVisualStyleBackColor = true;
            this.OpretKunde_btn.Click += new System.EventHandler(this.button5_Click);
            // 
            // FjernKunde_btn
            // 
            this.FjernKunde_btn.Enabled = false;
            this.FjernKunde_btn.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FjernKunde_btn.Location = new System.Drawing.Point(320, 178);
            this.FjernKunde_btn.Name = "FjernKunde_btn";
            this.FjernKunde_btn.Size = new System.Drawing.Size(96, 32);
            this.FjernKunde_btn.TabIndex = 1;
            this.FjernKunde_btn.Text = "Fjern kunde";
            this.FjernKunde_btn.UseVisualStyleBackColor = true;
            this.FjernKunde_btn.Click += new System.EventHandler(this.button6_Click);
            // 
            // VisKonto_btn
            // 
            this.VisKonto_btn.Enabled = false;
            this.VisKonto_btn.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.VisKonto_btn.Location = new System.Drawing.Point(10, 395);
            this.VisKonto_btn.Name = "VisKonto_btn";
            this.VisKonto_btn.Size = new System.Drawing.Size(92, 32);
            this.VisKonto_btn.TabIndex = 9;
            this.VisKonto_btn.Text = "Vis konti";
            this.VisKonto_btn.UseVisualStyleBackColor = true;
            this.VisKonto_btn.Click += new System.EventHandler(this.button8_Click);
            // 
            // OpretKonto_btn
            // 
            this.OpretKonto_btn.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OpretKonto_btn.Location = new System.Drawing.Point(112, 12);
            this.OpretKonto_btn.Name = "OpretKonto_btn";
            this.OpretKonto_btn.Size = new System.Drawing.Size(96, 32);
            this.OpretKonto_btn.TabIndex = 2;
            this.OpretKonto_btn.Text = "Opret konto";
            this.OpretKonto_btn.UseVisualStyleBackColor = true;
            this.OpretKonto_btn.Click += new System.EventHandler(this.button9_Click);
            // 
            // FjernKonto_btn
            // 
            this.FjernKonto_btn.Enabled = false;
            this.FjernKonto_btn.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FjernKonto_btn.Location = new System.Drawing.Point(320, 347);
            this.FjernKonto_btn.Name = "FjernKonto_btn";
            this.FjernKonto_btn.Size = new System.Drawing.Size(88, 32);
            this.FjernKonto_btn.TabIndex = 3;
            this.FjernKonto_btn.Text = "Fjern konto";
            this.FjernKonto_btn.UseVisualStyleBackColor = true;
            this.FjernKonto_btn.Click += new System.EventHandler(this.button10_Click);
            // 
            // Hæv_btn
            // 
            this.Hæv_btn.Enabled = false;
            this.Hæv_btn.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Hæv_btn.Location = new System.Drawing.Point(530, 347);
            this.Hæv_btn.Name = "Hæv_btn";
            this.Hæv_btn.Size = new System.Drawing.Size(90, 32);
            this.Hæv_btn.TabIndex = 4;
            this.Hæv_btn.Text = "Hæv beløb";
            this.Hæv_btn.UseVisualStyleBackColor = true;
            this.Hæv_btn.Click += new System.EventHandler(this.button11_Click);
            // 
            // Indsæt_btn
            // 
            this.Indsæt_btn.Enabled = false;
            this.Indsæt_btn.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Indsæt_btn.Location = new System.Drawing.Point(413, 347);
            this.Indsæt_btn.Name = "Indsæt_btn";
            this.Indsæt_btn.Size = new System.Drawing.Size(111, 32);
            this.Indsæt_btn.TabIndex = 5;
            this.Indsæt_btn.Text = "Indsæt beløb";
            this.Indsæt_btn.UseVisualStyleBackColor = true;
            this.Indsæt_btn.Click += new System.EventHandler(this.button12_Click);
            // 
            // UdskrivTrans_btn
            // 
            this.UdskrivTrans_btn.Enabled = false;
            this.UdskrivTrans_btn.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UdskrivTrans_btn.Location = new System.Drawing.Point(108, 395);
            this.UdskrivTrans_btn.Name = "UdskrivTrans_btn";
            this.UdskrivTrans_btn.Size = new System.Drawing.Size(180, 32);
            this.UdskrivTrans_btn.TabIndex = 10;
            this.UdskrivTrans_btn.Text = "Udskriv transaktioner";
            this.UdskrivTrans_btn.UseVisualStyleBackColor = true;
            this.UdskrivTrans_btn.Click += new System.EventHandler(this.button13_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.comboBox2);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.Submit_btn);
            this.panel1.Controls.Add(this.textBox5);
            this.panel1.Controls.Add(this.textBox4);
            this.panel1.Controls.Add(this.textBox3);
            this.panel1.Controls.Add(this.textBox2);
            this.panel1.Controls.Add(this.textBox1);
            this.panel1.Location = new System.Drawing.Point(10, 50);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(278, 329);
            this.panel1.TabIndex = 7;
            // 
            // comboBox2
            // 
            this.comboBox2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.comboBox2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(5, 171);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(156, 25);
            this.comboBox2.TabIndex = 2;
            this.comboBox2.Visible = false;
            this.comboBox2.Enter += new System.EventHandler(this.comboBox2_Enter);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(3, 146);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(108, 19);
            this.label5.TabIndex = 4;
            this.label5.Text = "Telefon nummer";
            this.label5.Visible = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(3, 116);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(91, 19);
            this.label4.TabIndex = 3;
            this.label4.Text = "Post nummer";
            this.label4.Visible = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(3, 86);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(57, 19);
            this.label3.TabIndex = 2;
            this.label3.Text = "Adresse";
            this.label3.Visible = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(3, 56);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 19);
            this.label2.TabIndex = 1;
            this.label2.Text = "Efternavn";
            this.label2.Visible = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(3, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 19);
            this.label1.TabIndex = 0;
            this.label1.Text = "Fornavn";
            this.label1.Visible = false;
            // 
            // Submit_btn
            // 
            this.Submit_btn.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Submit_btn.Location = new System.Drawing.Point(113, 292);
            this.Submit_btn.Name = "Submit_btn";
            this.Submit_btn.Size = new System.Drawing.Size(156, 32);
            this.Submit_btn.TabIndex = 6;
            this.Submit_btn.Text = "Submit";
            this.Submit_btn.UseVisualStyleBackColor = true;
            this.Submit_btn.Visible = false;
            this.Submit_btn.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(113, 142);
            this.textBox5.MaxLength = 11;
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(156, 25);
            this.textBox5.TabIndex = 5;
            this.textBox5.Visible = false;
            this.textBox5.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox5_KeyPress);
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(113, 113);
            this.textBox4.MaxLength = 4;
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(156, 25);
            this.textBox4.TabIndex = 4;
            this.textBox4.Visible = false;
            this.textBox4.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox5_KeyPress);
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(113, 83);
            this.textBox3.MaxLength = 40;
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(156, 25);
            this.textBox3.TabIndex = 3;
            this.textBox3.Visible = false;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(113, 53);
            this.textBox2.MaxLength = 40;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(156, 25);
            this.textBox2.TabIndex = 1;
            this.textBox2.Visible = false;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(113, 22);
            this.textBox1.MaxLength = 40;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(156, 25);
            this.textBox1.TabIndex = 0;
            this.textBox1.Visible = false;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(10, 430);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(610, 211);
            this.dataGridView1.TabIndex = 11;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(3, 75);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(45, 19);
            this.label11.TabIndex = 4;
            this.label11.Text = "TlfNr: ";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(3, 57);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(57, 19);
            this.label10.TabIndex = 3;
            this.label10.Text = "PostNr: ";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(3, 39);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(64, 19);
            this.label9.TabIndex = 2;
            this.label9.Text = "Adresse: ";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(3, 21);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(48, 19);
            this.label8.TabIndex = 1;
            this.label8.Text = "Navn: ";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(3, 3);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(70, 19);
            this.label7.TabIndex = 0;
            this.label7.Text = "KundeNr: ";
            // 
            // Saldo_label
            // 
            this.Saldo_label.AutoSize = true;
            this.Saldo_label.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Saldo_label.Location = new System.Drawing.Point(316, 408);
            this.Saldo_label.Name = "Saldo_label";
            this.Saldo_label.Size = new System.Drawing.Size(169, 19);
            this.Saldo_label.TabIndex = 13;
            this.Saldo_label.Text = "Samlet saldo for alle konti:";
            // 
            // SøgKunde_text
            // 
            this.SøgKunde_text.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.SøgKunde_text.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.SøgKunde_text.Location = new System.Drawing.Point(320, 26);
            this.SøgKunde_text.Name = "SøgKunde_text";
            this.SøgKunde_text.Size = new System.Drawing.Size(300, 25);
            this.SøgKunde_text.TabIndex = 14;
            this.SøgKunde_text.MouseClick += new System.Windows.Forms.MouseEventHandler(this.textBox6_Enter);
            this.SøgKunde_text.Enter += new System.EventHandler(this.textBox6_Enter);
            this.SøgKunde_text.KeyUp += new System.Windows.Forms.KeyEventHandler(this.textBox6_KeyUp);
            // 
            // SøgKunde_label
            // 
            this.SøgKunde_label.AutoSize = true;
            this.SøgKunde_label.Font = new System.Drawing.Font("Segoe UI", 7.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SøgKunde_label.Location = new System.Drawing.Point(316, 6);
            this.SøgKunde_label.Name = "SøgKunde_label";
            this.SøgKunde_label.Size = new System.Drawing.Size(114, 19);
            this.SøgKunde_label.TabIndex = 15;
            this.SøgKunde_label.Text = "Søg efter kunde:";
            // 
            // splitContainer1
            // 
            this.splitContainer1.Location = new System.Drawing.Point(320, 79);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.BackColor = System.Drawing.SystemColors.Control;
            this.splitContainer1.Panel1.Controls.Add(this.label7);
            this.splitContainer1.Panel1.Controls.Add(this.label9);
            this.splitContainer1.Panel1.Controls.Add(this.label8);
            this.splitContainer1.Panel1.Controls.Add(this.label10);
            this.splitContainer1.Panel1.Controls.Add(this.label11);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.BackColor = System.Drawing.SystemColors.Control;
            this.splitContainer1.Panel2.Controls.Add(this.label17);
            this.splitContainer1.Panel2.Controls.Add(this.label16);
            this.splitContainer1.Panel2.Controls.Add(this.label15);
            this.splitContainer1.Panel2.Controls.Add(this.label14);
            this.splitContainer1.Panel2.Controls.Add(this.label13);
            this.splitContainer1.Size = new System.Drawing.Size(300, 99);
            this.splitContainer1.SplitterDistance = 81;
            this.splitContainer1.TabIndex = 16;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(9, 75);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(53, 19);
            this.label17.TabIndex = 4;
            this.label17.Text = "label17";
            this.label17.Visible = false;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(9, 57);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(53, 19);
            this.label16.TabIndex = 3;
            this.label16.Text = "label16";
            this.label16.Visible = false;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(9, 39);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(53, 19);
            this.label15.TabIndex = 2;
            this.label15.Text = "label15";
            this.label15.Visible = false;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(9, 21);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(53, 19);
            this.label14.TabIndex = 1;
            this.label14.Text = "label14";
            this.label14.Visible = false;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(9, 3);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(53, 19);
            this.label13.TabIndex = 0;
            this.label13.Text = "label13";
            this.label13.Visible = false;
            // 
            // SamletBeløb_label
            // 
            this.SamletBeløb_label.AutoSize = true;
            this.SamletBeløb_label.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SamletBeløb_label.Location = new System.Drawing.Point(480, 408);
            this.SamletBeløb_label.Name = "SamletBeløb_label";
            this.SamletBeløb_label.Size = new System.Drawing.Size(17, 19);
            this.SamletBeløb_label.TabIndex = 17;
            this.SamletBeløb_label.Text = "0";
            this.SamletBeløb_label.Visible = false;
            // 
            // ValgteKunde_label
            // 
            this.ValgteKunde_label.AutoSize = true;
            this.ValgteKunde_label.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ValgteKunde_label.Location = new System.Drawing.Point(316, 57);
            this.ValgteKunde_label.Name = "ValgteKunde_label";
            this.ValgteKunde_label.Size = new System.Drawing.Size(183, 19);
            this.ValgteKunde_label.TabIndex = 18;
            this.ValgteKunde_label.Text = "Valgte kunde information:";
            // 
            // SøgKonto_text
            // 
            this.SøgKonto_text.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SøgKonto_text.Location = new System.Drawing.Point(320, 250);
            this.SøgKonto_text.Name = "SøgKonto_text";
            this.SøgKonto_text.Size = new System.Drawing.Size(300, 25);
            this.SøgKonto_text.TabIndex = 19;
            this.SøgKonto_text.KeyUp += new System.Windows.Forms.KeyEventHandler(this.SøgKonto_text_KeyUp);
            // 
            // SøgKonto_label
            // 
            this.SøgKonto_label.AutoSize = true;
            this.SøgKonto_label.Font = new System.Drawing.Font("Segoe UI", 7.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SøgKonto_label.Location = new System.Drawing.Point(316, 230);
            this.SøgKonto_label.Name = "SøgKonto_label";
            this.SøgKonto_label.Size = new System.Drawing.Size(112, 19);
            this.SøgKonto_label.TabIndex = 20;
            this.SøgKonto_label.Text = "Søg efter konto:";
            // 
            // splitContainer2
            // 
            this.splitContainer2.Location = new System.Drawing.Point(320, 303);
            this.splitContainer2.Name = "splitContainer2";
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.label20);
            this.splitContainer2.Panel1.Controls.Add(this.label12);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.BackColor = System.Drawing.SystemColors.Control;
            this.splitContainer2.Panel2.Controls.Add(this.label19);
            this.splitContainer2.Panel2.Controls.Add(this.label18);
            this.splitContainer2.Size = new System.Drawing.Size(300, 44);
            this.splitContainer2.SplitterDistance = 80;
            this.splitContainer2.TabIndex = 21;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(3, 21);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(66, 19);
            this.label20.TabIndex = 1;
            this.label20.Text = "KundeNr:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(3, 3);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(64, 19);
            this.label12.TabIndex = 0;
            this.label12.Text = "KontoNr:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(12, 21);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(53, 19);
            this.label19.TabIndex = 1;
            this.label19.Text = "label19";
            this.label19.Visible = false;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(12, 3);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(53, 19);
            this.label18.TabIndex = 0;
            this.label18.Text = "label18";
            this.label18.Visible = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(316, 280);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(181, 19);
            this.label6.TabIndex = 22;
            this.label6.Text = "Valgte konto information:";
            // 
            // Kundeoversigt_btn
            // 
            this.Kundeoversigt_btn.Location = new System.Drawing.Point(423, 178);
            this.Kundeoversigt_btn.Name = "Kundeoversigt_btn";
            this.Kundeoversigt_btn.Size = new System.Drawing.Size(197, 32);
            this.Kundeoversigt_btn.TabIndex = 23;
            this.Kundeoversigt_btn.Text = "Vis Kundeoversigt";
            this.Kundeoversigt_btn.UseVisualStyleBackColor = true;
            this.Kundeoversigt_btn.Click += new System.EventHandler(this.Kundeoversigt_btn_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(632, 653);
            this.Controls.Add(this.Kundeoversigt_btn);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.splitContainer2);
            this.Controls.Add(this.SøgKonto_label);
            this.Controls.Add(this.SøgKonto_text);
            this.Controls.Add(this.ValgteKunde_label);
            this.Controls.Add(this.SamletBeløb_label);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.SøgKunde_label);
            this.Controls.Add(this.SøgKunde_text);
            this.Controls.Add(this.Saldo_label);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.UdskrivTrans_btn);
            this.Controls.Add(this.Indsæt_btn);
            this.Controls.Add(this.Hæv_btn);
            this.Controls.Add(this.FjernKonto_btn);
            this.Controls.Add(this.OpretKonto_btn);
            this.Controls.Add(this.VisKonto_btn);
            this.Controls.Add(this.FjernKunde_btn);
            this.Controls.Add(this.OpretKunde_btn);
            this.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Scammerbank (Employee Edition)";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel1.PerformLayout();
            this.splitContainer2.Panel2.ResumeLayout(false);
            this.splitContainer2.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button OpretKunde_btn;
        private System.Windows.Forms.Button FjernKunde_btn;
        private System.Windows.Forms.Button VisKonto_btn;
        private System.Windows.Forms.Button OpretKonto_btn;
        private System.Windows.Forms.Button FjernKonto_btn;
        private System.Windows.Forms.Button Hæv_btn;
        private System.Windows.Forms.Button Indsæt_btn;
        private System.Windows.Forms.Button UdskrivTrans_btn;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Submit_btn;
        private System.Windows.Forms.Label Saldo_label;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox SøgKunde_text;
        private System.Windows.Forms.Label SøgKunde_label;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label SamletBeløb_label;
        private System.Windows.Forms.Label ValgteKunde_label;
        private System.Windows.Forms.TextBox SøgKonto_text;
        private System.Windows.Forms.Label SøgKonto_label;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Button Kundeoversigt_btn;
    }
}

